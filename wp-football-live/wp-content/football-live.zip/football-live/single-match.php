<?php
if (!defined('ABSPATH')) { exit; }
get_header();

while (have_posts()) : the_post();
  $stream = trim((string)get_post_meta(get_the_ID(), '_fl_stream_url', true));
  $home = get_post_meta(get_the_ID(), '_fl_home_team', true);
  $away = get_post_meta(get_the_ID(), '_fl_away_team', true);
?>

<main class="container section">
  <div class="iframe-wrap">
    <?php if ($stream !== '') : ?>
      <div class="ratio">
        <iframe
          src="<?php echo esc_url($stream); ?>"
          allowfullscreen
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
          title="<?php echo esc_attr(($home ?: 'Home') . ' vs ' . ($away ?: 'Away')); ?>"
        ></iframe>
      </div>
    <?php else: ?>
      <div class="ratio" style="display:flex;align-items:center;justify-content:center;color:#888;background:#111;">
        Stream not available
      </div>
    <?php endif; ?>
  </div>

  <div style="margin-top:16px;">
    <a class="text-primary" href="<?php echo esc_url(home_url('/')); ?>">← Back to Home</a>
  </div>
</main>

<?php endwhile; ?>
<?php get_footer(); ?>

