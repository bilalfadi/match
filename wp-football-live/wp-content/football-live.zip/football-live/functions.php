<?php
if (!defined('ABSPATH')) { exit; }

define('FOOTBALL_LIVE_THEME_VERSION', '0.1.0');

function football_live_theme_enqueue_assets() {
  wp_enqueue_style('football-live-style', get_stylesheet_uri(), array(), FOOTBALL_LIVE_THEME_VERSION);
}
add_action('wp_enqueue_scripts', 'football_live_theme_enqueue_assets');

function football_live_theme_setup() {
  add_theme_support('title-tag');
  add_theme_support('post-thumbnails');
  add_theme_support('html5', array('search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script'));

  register_nav_menus(array(
    'primary' => __('Primary Menu', 'football-live'),
    'footer' => __('Footer Menu', 'football-live'),
  ));
}
add_action('after_setup_theme', 'football_live_theme_setup');

// Force page template by slug so News/Football/Premier League pages show posts grid (WP_Query by category)
// Ref: page slug = category slug => template runs WP_Query(category_name => slug) so grid is always live
function football_live_page_template_by_slug($template) {
  $page = get_queried_object();
  if (!$page || !isset($page->post_type) || $page->post_type !== 'page') return $template;
  $slug = strtolower((string) $page->post_name);
  $map = array(
    'news' => 'page-news.php',
    'football' => 'page-football.php',
    'premier-league' => 'page-premier-league.php',
  );
  if (!isset($map[$slug])) return $template;
  $custom = get_stylesheet_directory() . '/' . $map[$slug];
  if (file_exists($custom)) return $custom;
  return $template;
}
add_filter('page_template', 'football_live_page_template_by_slug');

function football_live_default_badge_url() {
  // Remote fallback so theme works without uploading images
  return 'https://images.unsplash.com/photo-1574629810360-7efbbe195018?w=96&h=96&fit=crop';
}

function football_live_get_team_logo_url($maybe_url) {
  $u = trim((string)$maybe_url);
  if ($u === '') return football_live_default_badge_url();
  // Treat these as placeholders (show default image instead)
  if (stripos($u, 'ui-avatars.com') !== false) return football_live_default_badge_url();
  if (stripos($u, 'placehold.co') !== false) return football_live_default_badge_url();
  return esc_url($u);
}

