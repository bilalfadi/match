<?php
if (!defined('ABSPATH')) { exit; }
get_header();
?>

<main class="container section">
  <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
    <div class="glass-card" style="padding:18px;">
      <h1 style="margin:0 0 14px;"><?php the_title(); ?></h1>
      <div style="line-height:1.7;color:#e5e5e5;">
        <?php the_content(); ?>
      </div>
    </div>
  <?php endwhile; endif; ?>
</main>

<?php get_footer(); ?>

