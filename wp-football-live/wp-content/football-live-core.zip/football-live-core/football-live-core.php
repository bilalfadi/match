<?php
/**
 * Plugin Name: Football Live Core
 * Description: Matches CPT + embed extraction from detail URL + shortcodes.
 * Version: 0.1.0
 */

if (!defined('ABSPATH')) { exit; }

define('FOOTBALL_LIVE_CORE_VERSION', '0.1.0');

// Plugin activation: create core categories/pages + sample posts + flush permalinks
function flc_on_activate() {
  // Ensure CPT is registered so rewrite rules include /match/{slug}
  flc_register_match_cpt();

  // Core categories for homepage sections
  $cats = array(
    array('name' => 'News', 'slug' => 'news'),
    array('name' => 'Football', 'slug' => 'football'),
    array('name' => 'Premier League', 'slug' => 'premier-league'),
  );
  foreach ($cats as $c) {
    if (!term_exists($c['slug'], 'category')) {
      wp_insert_term($c['name'], 'category', array('slug' => $c['slug']));
    }
  }

  // Helper: ensure a page with given slug exists
  $ensure_page = function ($title, $slug) {
    $page = get_page_by_path($slug);
    if ($page) return $page->ID;
    return wp_insert_post(array(
      'post_title'   => $title,
      'post_name'    => $slug,
      'post_type'    => 'page',
      'post_status'  => 'publish',
      'post_content' => '',
    ));
  };

  // Header pages: same slug as category so template can show that category's posts (grid)
  $home_id     = $ensure_page('Home', 'home');
  $news_id     = $ensure_page('News', 'news');
  $football_id = $ensure_page('Football', 'football');
  $pl_id       = $ensure_page('Premier League', 'premier-league');
  $about_id    = $ensure_page('About Us', 'about');
  $disc_id     = $ensure_page('Disclaimer', 'disclaimer');
  $terms_id    = $ensure_page('Terms & Conditions', 'terms');
  $priv_id     = $ensure_page('Privacy Policy', 'privacy');
  $cookies_id  = $ensure_page('Cookies Policy', 'cookies');
  $ccpa_id     = $ensure_page('CCPA', 'ccpa');
  $contact_id  = $ensure_page('Contact Us', 'contact');

  // Static homepage ⇒ our Home page
  if ($home_id && !is_wp_error($home_id)) {
    update_option('show_on_front', 'page');
    update_option('page_on_front', $home_id);
  }

  // Create one sample post in each category if empty (so cards appear)
  $create_sample = function ($title, $slug) {
    $cat = get_term_by('slug', $slug, 'category');
    if (!$cat || is_wp_error($cat)) return;
    $existing = get_posts(array(
      'post_type'      => 'post',
      'posts_per_page' => 1,
      'cat'            => $cat->term_id,
      'fields'         => 'ids',
    ));
    if ($existing) return;
    wp_insert_post(array(
      'post_title'   => $title,
      'post_type'    => 'post',
      'post_status'  => 'publish',
      'post_content' => 'Sample content for ' . $title . '. Replace with your own article.',
      'post_category'=> array($cat->term_id),
    ));
  };

  $create_sample('Sample News Post', 'news');
  $create_sample('Sample Football Post', 'football');
  $create_sample('Sample Premier League Post', 'premier-league');

  // Make sure permalinks know about /match/ and new pages
  flush_rewrite_rules();
}
register_activation_hook(__FILE__, 'flc_on_activate');

function flc_register_match_cpt() {
  register_post_type('match', array(
    'labels' => array(
      'name' => 'Matches',
      'singular_name' => 'Match',
      'add_new_item' => 'Add Match',
      'edit_item' => 'Edit Match',
    ),
    'public' => true,
    'has_archive' => true,
    'rewrite' => array('slug' => 'match'),
    'menu_icon' => 'dashicons-video-alt3',
    'supports' => array('title', 'editor'),
    'show_in_rest' => true,
  ));
}
add_action('init', 'flc_register_match_cpt');

function flc_add_match_metaboxes() {
  add_meta_box('flc_match_meta', 'Match Details', 'flc_render_match_metabox', 'match', 'normal', 'high');
}
add_action('add_meta_boxes_match', 'flc_add_match_metaboxes');

function flc_render_match_metabox($post) {
  wp_nonce_field('flc_match_meta_save', 'flc_match_meta_nonce');
  $fields = array(
    'detail_url' => get_post_meta($post->ID, '_fl_detail_url', true),
    'stream_url' => get_post_meta($post->ID, '_fl_stream_url', true),
    'league_name' => get_post_meta($post->ID, '_fl_league_name', true),
    'league_logo' => get_post_meta($post->ID, '_fl_league_logo', true),
    'league_color' => get_post_meta($post->ID, '_fl_league_color', true),
    'home_team' => get_post_meta($post->ID, '_fl_home_team', true),
    'away_team' => get_post_meta($post->ID, '_fl_away_team', true),
    'home_logo' => get_post_meta($post->ID, '_fl_home_logo', true),
    'away_logo' => get_post_meta($post->ID, '_fl_away_logo', true),
    'status' => get_post_meta($post->ID, '_fl_status', true),
    'match_time' => get_post_meta($post->ID, '_fl_match_time', true),
  );

  $status = $fields['status'] ?: 'LIVE';
  ?>
  <p><label><strong>Match Page URL</strong></label><br>
    <input style="width:100%" type="url" name="fl_detail_url" value="<?php echo esc_attr($fields['detail_url']); ?>" placeholder="https://..." />
  </p>
  <p><label><strong>Stream URL</strong></label><br>
    <input style="width:100%" type="url" name="fl_stream_url" value="<?php echo esc_attr($fields['stream_url']); ?>" placeholder="https://..." />
  </p>
  <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px;">
    <p><label><strong>League / Tournament</strong></label><br>
      <input style="width:100%" type="text" name="fl_league_name" value="<?php echo esc_attr($fields['league_name']); ?>" placeholder="Premier League" />
    </p>
    <p><label><strong>League Logo URL</strong></label><br>
      <input style="width:100%" type="url" name="fl_league_logo" value="<?php echo esc_attr($fields['league_logo']); ?>" placeholder="https://..." />
    </p>
    <p><label><strong>League Color</strong></label><br>
      <input style="width:100%" type="text" name="fl_league_color" value="<?php echo esc_attr($fields['league_color']); ?>" placeholder="#7C3AED" />
      <span style="display:block;color:#666;font-size:12px;margin-top:4px;">Hex color (optional)</span>
    </p>
  </div>
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
    <p><label><strong>Home Team</strong></label><br>
      <input style="width:100%" type="text" name="fl_home_team" value="<?php echo esc_attr($fields['home_team']); ?>" />
    </p>
    <p><label><strong>Away Team</strong></label><br>
      <input style="width:100%" type="text" name="fl_away_team" value="<?php echo esc_attr($fields['away_team']); ?>" />
    </p>
    <p><label><strong>Home Logo URL (optional)</strong></label><br>
      <input style="width:100%" type="url" name="fl_home_logo" value="<?php echo esc_attr($fields['home_logo']); ?>" placeholder="https://..." />
    </p>
    <p><label><strong>Away Logo URL (optional)</strong></label><br>
      <input style="width:100%" type="url" name="fl_away_logo" value="<?php echo esc_attr($fields['away_logo']); ?>" placeholder="https://..." />
    </p>
  </div>
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
    <p><label><strong>Status</strong></label><br>
      <select name="fl_status" style="width:100%">
        <?php foreach (array('LIVE','UPCOMING','FINISHED') as $s) : ?>
          <option value="<?php echo esc_attr($s); ?>" <?php selected($status, $s); ?>><?php echo esc_html($s); ?></option>
        <?php endforeach; ?>
      </select>
    </p>
    <p><label><strong>Match time (ISO or datetime)</strong></label><br>
      <input style="width:100%" type="text" name="fl_match_time" value="<?php echo esc_attr($fields['match_time']); ?>" placeholder="2026-02-25T10:00:00Z" />
    </p>
  </div>

  <p>
    <label>
      <input type="checkbox" name="fl_fetch_on_save" value="1" checked>
      Fetch teams + stream URL from Match Page URL on save
    </label>
  </p>
  <?php
}

function flc_http_get($url) {
  $resp = wp_remote_get($url, array(
    'timeout' => 20,
    'redirection' => 5,
    'headers' => array(
      'User-Agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
    ),
  ));
  if (is_wp_error($resp)) return null;
  $code = wp_remote_retrieve_response_code($resp);
  if ($code < 200 || $code >= 300) return null;
  return wp_remote_retrieve_body($resp);
}

function flc_parse_teams_from_title($title) {
  $t = trim((string)$title);
  if ($t === '') return null;
  if (preg_match('/(.+?)\s+vs\.?\s+(.+?)(?:\s+[-–|]|\s+Live|$)/i', $t, $m) || preg_match('/(.+?)\s+vs\.?\s+(.+)/i', $t, $m)) {
    $home = trim($m[1]);
    $away = trim(preg_replace('/\s+Live\s+stream.*$/i', '', $m[2]));
    if ($home !== '' && $away !== '') return array($home, $away);
  }
  return null;
}

function flc_is_invalid_embed($url) {
  $u = trim((string)$url);
  if ($u === '') return true;
  $lu = strtolower($u);
  if ($lu === 'about:blank' || $lu === 'about:srcdoc') return true;
  // PHP 7/8 compatible "starts with"
  if (substr($lu, 0, 11) === 'javascript:' || substr($lu, 0, 5) === 'data:') return true;
  return false;
}

function flc_url_resolve($base, $rel) {
  $rel = trim((string)$rel);
  if ($rel === '') return '';
  if (preg_match('/^https?:\/\//i', $rel)) return esc_url_raw($rel);

  $b = wp_parse_url($base);
  if (!$b || empty($b['scheme']) || empty($b['host'])) return esc_url_raw($rel);
  $scheme = $b['scheme'];
  $host = $b['host'];
  $port = isset($b['port']) ? ':' . $b['port'] : '';
  $base_path = isset($b['path']) ? $b['path'] : '/';
  $base_dir = preg_replace('/\/[^\/]*$/', '/', $base_path);

  if (substr($rel, 0, 2) === '//') return esc_url_raw($scheme . ':' . $rel);
  if (substr($rel, 0, 1) === '/') return esc_url_raw($scheme . '://' . $host . $port . $rel);
  return esc_url_raw($scheme . '://' . $host . $port . $base_dir . $rel);
}

function flc_find_iframe_src($html, $base_url) {
  if (!$html) return '';
  // quick regex for iframe src (first valid)
  if (preg_match_all('/<iframe[^>]+src=[\"\']([^\"\']+)[\"\']/i', $html, $m)) {
    foreach ($m[1] as $src) {
      $src = trim((string)$src);
      if ($src === '' || flc_is_invalid_embed($src)) continue;
      $resolved = flc_url_resolve($base_url, $src);
      if ($resolved === '' || flc_is_invalid_embed($resolved)) continue;
      return $resolved;
    }
  }
  return '';
}

function flc_extract_from_detail_url($detail_url) {
  $html = flc_http_get($detail_url);
  if (!$html) return array(null, null, '', null, null);
  $title = '';
  if (preg_match('/<title[^>]*>(.*?)<\/title>/is', $html, $m)) {
    $title = wp_strip_all_tags($m[1]);
  }
  $teams = flc_parse_teams_from_title($title);
  $home = $teams ? $teams[0] : null;
  $away = $teams ? $teams[1] : null;
  $embed = flc_find_iframe_src($html, $detail_url);
  // Very simple league logo detection based on common keywords
  $league_name = null;
  $league_logo = null;
  if (preg_match_all('/<img[^>]+>/i', $html, $imgs)) {
    $patterns = array(
      'UEFA Champions League' => array('champions league', 'ucl'),
      'Premier League' => array('premier league', 'epl'),
      'La Liga' => array('la liga', 'laliga'),
      'Bundesliga' => array('bundesliga'),
      'Serie A' => array('serie a'),
      'Ligue 1' => array('ligue 1'),
      'Europa League' => array('europa league'),
    );
    foreach ($imgs[0] as $tag) {
      $tag_lower = strtolower($tag);
      $src = '';
      if (preg_match('/src=[\"\']([^\"\']+)[\"\']/i', $tag, $m2)) {
        $src = trim($m2[1]);
      }
      $alt = '';
      if (preg_match('/alt=[\"\']([^\"\']+)[\"\']/i', $tag, $m3)) {
        $alt = strtolower(trim($m3[1]));
      }
      foreach ($patterns as $lname => $keys) {
        foreach ($keys as $key) {
          if (strpos($tag_lower, $key) !== false || ($alt && strpos($alt, $key) !== false)) {
            $league_name = $lname;
            if ($src) {
              $league_logo = flc_url_resolve($detail_url, $src);
            }
            break 3;
          }
        }
      }
    }
  }
  return array($home, $away, $embed, $league_name, $league_logo);
}

function flc_save_match_meta($post_id) {
  if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
  if (!isset($_POST['flc_match_meta_nonce']) || !wp_verify_nonce($_POST['flc_match_meta_nonce'], 'flc_match_meta_save')) return;
  if (!current_user_can('edit_post', $post_id)) return;

  $detail = isset($_POST['fl_detail_url']) ? esc_url_raw(trim($_POST['fl_detail_url'])) : '';
  $stream = isset($_POST['fl_stream_url']) ? esc_url_raw(trim($_POST['fl_stream_url'])) : '';
  $league_name = isset($_POST['fl_league_name']) ? sanitize_text_field($_POST['fl_league_name']) : '';
  $league_logo = isset($_POST['fl_league_logo']) ? esc_url_raw(trim($_POST['fl_league_logo'])) : '';
  $league_color = isset($_POST['fl_league_color']) ? sanitize_text_field($_POST['fl_league_color']) : '';
  $home = isset($_POST['fl_home_team']) ? sanitize_text_field($_POST['fl_home_team']) : '';
  $away = isset($_POST['fl_away_team']) ? sanitize_text_field($_POST['fl_away_team']) : '';
  $home_logo = isset($_POST['fl_home_logo']) ? esc_url_raw(trim($_POST['fl_home_logo'])) : '';
  $away_logo = isset($_POST['fl_away_logo']) ? esc_url_raw(trim($_POST['fl_away_logo'])) : '';
  $status = isset($_POST['fl_status']) ? sanitize_text_field($_POST['fl_status']) : 'LIVE';
  $match_time = isset($_POST['fl_match_time']) ? sanitize_text_field($_POST['fl_match_time']) : '';

  update_post_meta($post_id, '_fl_detail_url', $detail);
  update_post_meta($post_id, '_fl_stream_url', $stream);
  update_post_meta($post_id, '_fl_league_name', $league_name);
  update_post_meta($post_id, '_fl_league_logo', $league_logo);
  update_post_meta($post_id, '_fl_league_color', $league_color);
  update_post_meta($post_id, '_fl_home_team', $home);
  update_post_meta($post_id, '_fl_away_team', $away);
  update_post_meta($post_id, '_fl_home_logo', $home_logo);
  update_post_meta($post_id, '_fl_away_logo', $away_logo);
  update_post_meta($post_id, '_fl_status', in_array($status, array('LIVE','UPCOMING','FINISHED'), true) ? $status : 'LIVE');
  update_post_meta($post_id, '_fl_match_time', $match_time);

  $do_fetch = isset($_POST['fl_fetch_on_save']) && $detail;
  if ($do_fetch) {
    list($p_home, $p_away, $p_stream, $p_league_name, $p_league_logo) = flc_extract_from_detail_url($detail);
    if ($p_home) update_post_meta($post_id, '_fl_home_team', $p_home);
    if ($p_away) update_post_meta($post_id, '_fl_away_team', $p_away);
    if ($p_stream) update_post_meta($post_id, '_fl_stream_url', $p_stream);
    if ($p_league_name) update_post_meta($post_id, '_fl_league_name', $p_league_name);
    if ($p_league_logo) update_post_meta($post_id, '_fl_league_logo', $p_league_logo);

    // If still no stream URL, keep as draft so it won't appear on homepage
    $final_stream = trim((string)get_post_meta($post_id, '_fl_stream_url', true));
    if ($final_stream === '') {
      // move to draft
      remove_action('save_post_match', 'flc_save_match_meta');
      wp_update_post(array('ID' => $post_id, 'post_status' => 'draft'));
      add_action('save_post_match', 'flc_save_match_meta');
    } else {
      // Set title if empty
      $final_home = get_post_meta($post_id, '_fl_home_team', true);
      $final_away = get_post_meta($post_id, '_fl_away_team', true);
      $wanted_title = trim($final_home . ' vs ' . $final_away);
      if ($wanted_title && get_the_title($post_id) !== $wanted_title) {
        remove_action('save_post_match', 'flc_save_match_meta');
        wp_update_post(array('ID' => $post_id, 'post_title' => $wanted_title));
        add_action('save_post_match', 'flc_save_match_meta');
      }
    }
  }
}
add_action('save_post_match', 'flc_save_match_meta');

function flc_matches_shortcode($atts) {
  $atts = shortcode_atts(array(
    'status' => 'LIVE',
    'limit' => 10,
  ), $atts);
  $status = strtoupper(trim((string)$atts['status']));
  $limit = max(1, min(50, intval($atts['limit'])));

  $q = new WP_Query(array(
    'post_type' => 'match',
    'posts_per_page' => $limit,
    'post_status' => 'publish',
    'meta_key' => '_fl_status',
    'meta_value' => $status,
  ));

  if (!$q->have_posts()) return '<p class="muted">No matches.</p>';

  $out = '<div style="display:flex;flex-direction:column;gap:12px;">';
  while ($q->have_posts()) {
    $q->the_post();
    $id = get_the_ID();
    $home = get_post_meta($id, '_fl_home_team', true);
    $away = get_post_meta($id, '_fl_away_team', true);
    $home_logo = get_post_meta($id, '_fl_home_logo', true);
    $away_logo = get_post_meta($id, '_fl_away_logo', true);
    $league_name = get_post_meta($id, '_fl_league_name', true);
    $league_logo = get_post_meta($id, '_fl_league_logo', true);
    $league_color = get_post_meta($id, '_fl_league_color', true);
    $time = get_post_meta($id, '_fl_match_time', true);
    $stream = trim((string)get_post_meta($id, '_fl_stream_url', true));

    if ($stream === '') continue; // never show without stream

    $home_img = function_exists('football_live_get_team_logo_url') ? football_live_get_team_logo_url($home_logo) : $home_logo;
    $away_img = function_exists('football_live_get_team_logo_url') ? football_live_get_team_logo_url($away_logo) : $away_logo;

    $time_label = $status === 'LIVE' ? 'LIVE' : ($time ? esc_html($time) : '');

    $style = '';
    if ($league_color) {
      $style = ' style="--league:' . esc_attr($league_color) . ';"';
    }
    $title_line = trim(($home ?: 'Home') . ' vs ' . ($away ?: 'Away'));

    $out .= '<a class="match-card" href="' . esc_url(get_permalink($id)) . '"' . $style . '>';
    $out .=   '<div class="match-left">';
    if ($league_logo) {
      $out .= '<span class="league-badge"><img alt="" src="' . esc_url($league_logo) . '"></span>';
    }
    $out .=     '<div class="match-text">';
    $out .=       '<div class="match-title">' . esc_html($title_line) . '</div>';
    if ($league_name) {
      $out .=     '<div class="match-league-name">' . esc_html($league_name) . '</div>';
    }
    if ($time_label) {
      $out .=     '<div class="match-time"><span class="match-time-icon"></span><span>' . esc_html($time_label) . '</span></div>';
    }
    $out .=     '</div>'; // .match-text
    $out .=   '</div>'; // .match-left
    $out .=   '<span class="match-watch">Watch Now</span>';
    $out .= '</a>';
  }
  wp_reset_postdata();
  $out .= '</div>';
  return $out;
}
add_shortcode('football_live_matches', 'flc_matches_shortcode');

